import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { supabase } from "./supabase";
import { insertHabitSchema, updateHabitSchema, insertHabitCompletionSchema } from "@shared/schema";
import { z } from "zod";

// Middleware to verify Supabase JWT token
const authenticateUser = async (req: any, res: any, next: any) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const token = authHeader.split(' ')[1];
    const { data: user, error } = await supabase.auth.getUser(token);

    if (error || !user.user) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    req.user = user.user;
    next();
  } catch (error) {
    return res.status(401).json({ message: "Unauthorized" });
  }
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  app.post('/api/auth/signup', async (req, res) => {
    try {
      const { email, password, firstName, lastName } = req.body;
      
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
      });

      if (error) {
        return res.status(400).json({ message: error.message });
      }

      if (data.user) {
        // Create user record in our database
        await storage.upsertUser({
          id: data.user.id,
          email: data.user.email!,
          firstName,
          lastName,
        });
      }

      res.json({ user: data.user, session: data.session });
    } catch (error) {
      console.error("Error during signup:", error);
      res.status(500).json({ message: "Failed to create account" });
    }
  });

  app.post('/api/auth/signin', async (req, res) => {
    try {
      const { email, password } = req.body;
      
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        return res.status(400).json({ message: error.message });
      }

      res.json({ user: data.user, session: data.session });
    } catch (error) {
      console.error("Error during signin:", error);
      res.status(500).json({ message: "Failed to sign in" });
    }
  });

  app.post('/api/auth/signout', async (req, res) => {
    try {
      // Client-side will handle signout with Supabase
      res.json({ message: "Signed out successfully" });
    } catch (error) {
      console.error("Error during signout:", error);
      res.status(500).json({ message: "Failed to sign out" });
    }
  });

  app.get('/api/auth/user', authenticateUser, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Habit routes
  app.get("/api/habits", authenticateUser, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const habits = await storage.getHabits(userId);
      res.json(habits);
    } catch (error) {
      console.error("Error fetching habits:", error);
      res.status(500).json({ message: "Failed to fetch habits" });
    }
  });

  app.post("/api/habits", authenticateUser, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const validatedData = insertHabitSchema.parse(req.body);
      const habit = await storage.createHabit({ ...validatedData, userId });
      res.status(201).json(habit);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid habit data", errors: error.errors });
      } else {
        console.error("Error creating habit:", error);
        res.status(500).json({ message: "Failed to create habit" });
      }
    }
  });

  app.put("/api/habits/:id", authenticateUser, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const habitId = parseInt(req.params.id);
      const validatedData = updateHabitSchema.parse(req.body);
      
      const habit = await storage.updateHabit(habitId, userId, validatedData);
      if (!habit) {
        return res.status(404).json({ message: "Habit not found" });
      }
      
      res.json(habit);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid habit data", errors: error.errors });
      } else {
        console.error("Error updating habit:", error);
        res.status(500).json({ message: "Failed to update habit" });
      }
    }
  });

  app.delete("/api/habits/:id", authenticateUser, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const habitId = parseInt(req.params.id);
      
      const success = await storage.deleteHabit(habitId, userId);
      if (!success) {
        return res.status(404).json({ message: "Habit not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting habit:", error);
      res.status(500).json({ message: "Failed to delete habit" });
    }
  });

  // Habit completion routes
  app.post("/api/habits/:id/toggle", authenticateUser, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const habitId = parseInt(req.params.id);
      const date = req.body.date || new Date().toISOString().split('T')[0];
      
      const completion = await storage.toggleHabitCompletion(habitId, userId, date);
      res.json({ completed: !!completion, completion });
    } catch (error) {
      console.error("Error toggling habit completion:", error);
      res.status(500).json({ message: "Failed to toggle habit completion" });
    }
  });

  app.get("/api/completions", authenticateUser, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const startDate = req.query.startDate as string || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
      const endDate = req.query.endDate as string || new Date().toISOString().split('T')[0];
      
      const completions = await storage.getHabitCompletions(userId, startDate, endDate);
      res.json(completions);
    } catch (error) {
      console.error("Error fetching completions:", error);
      res.status(500).json({ message: "Failed to fetch completions" });
    }
  });

  app.get("/api/stats", authenticateUser, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const stats = await storage.getHabitStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
