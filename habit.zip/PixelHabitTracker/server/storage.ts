import {
  users,
  habits,
  habitCompletions,
  type User,
  type UpsertUser,
  type Habit,
  type InsertHabit,
  type UpdateHabit,
  type HabitCompletion,
  type InsertHabitCompletion,
  type HabitWithCompletions,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, gte, lte, count, sql } from "drizzle-orm";
import { supabase } from "./supabase";

// Interface for storage operations
export interface IStorage {
  // User operations
  // (IMPORTANT) these user operations are mandatory for Replit Auth.
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Habit operations
  getHabits(userId: string): Promise<HabitWithCompletions[]>;
  getHabit(id: number, userId: string): Promise<Habit | undefined>;
  createHabit(habit: InsertHabit & { userId: string }): Promise<Habit>;
  updateHabit(id: number, userId: string, updates: UpdateHabit): Promise<Habit | undefined>;
  deleteHabit(id: number, userId: string): Promise<boolean>;
  
  // Habit completion operations
  toggleHabitCompletion(habitId: number, userId: string, date: string): Promise<HabitCompletion | null>;
  getHabitCompletions(userId: string, startDate: string, endDate: string): Promise<HabitCompletion[]>;
  getHabitStats(userId: string): Promise<{
    totalHabits: number;
    completedToday: number;
    currentStreak: number;
    weeklyCompletionRate: number;
    totalPoints: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  // (IMPORTANT) these user operations are mandatory for Replit Auth.

  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Habit operations
  async getHabits(userId: string): Promise<HabitWithCompletions[]> {
    const today = new Date().toISOString().split('T')[0];
    const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

    const userHabits = await db
      .select({
        id: habits.id,
        userId: habits.userId,
        name: habits.name,
        description: habits.description,
        frequency: habits.frequency,
        category: habits.category,
        isActive: habits.isActive,
        createdAt: habits.createdAt,
        updatedAt: habits.updatedAt,
      })
      .from(habits)
      .where(and(eq(habits.userId, userId), eq(habits.isActive, true)))
      .orderBy(desc(habits.createdAt));

    const habitsWithCompletions = await Promise.all(
      userHabits.map(async (habit) => {
        // Get all completions for this habit
        const completions = await db
          .select()
          .from(habitCompletions)
          .where(eq(habitCompletions.habitId, habit.id))
          .orderBy(desc(habitCompletions.completedAt));

        // Check if completed today
        const todayCompletion = completions.find(c => c.completedAt === today);
        const isCompletedToday = !!todayCompletion;

        // Calculate current streak
        let currentStreak = 0;
        const sortedCompletions = completions.sort((a, b) => new Date(b.completedAt).getTime() - new Date(a.completedAt).getTime());
        
        if (isCompletedToday) {
          currentStreak = 1;
          let checkDate = new Date(today);
          checkDate.setDate(checkDate.getDate() - 1);
          
          for (const completion of sortedCompletions.slice(1)) {
            const completionDate = checkDate.toISOString().split('T')[0];
            if (completion.completedAt === completionDate) {
              currentStreak++;
              checkDate.setDate(checkDate.getDate() - 1);
            } else {
              break;
            }
          }
        }

        // Calculate completion rate (last 7 days)
        const weekCompletions = completions.filter(c => c.completedAt >= weekAgo);
        const completionRate = Math.round((weekCompletions.length / 7) * 100);

        return {
          ...habit,
          completions,
          isCompletedToday,
          currentStreak,
          completionRate,
        };
      })
    );

    return habitsWithCompletions;
  }

  async getHabit(id: number, userId: string): Promise<Habit | undefined> {
    const [habit] = await db
      .select()
      .from(habits)
      .where(and(eq(habits.id, id), eq(habits.userId, userId)));
    return habit;
  }

  async createHabit(habitData: InsertHabit & { userId: string }): Promise<Habit> {
    const [habit] = await db
      .insert(habits)
      .values(habitData)
      .returning();
    return habit;
  }

  async updateHabit(id: number, userId: string, updates: UpdateHabit): Promise<Habit | undefined> {
    const [habit] = await db
      .update(habits)
      .set({ ...updates, updatedAt: new Date() })
      .where(and(eq(habits.id, id), eq(habits.userId, userId)))
      .returning();
    return habit;
  }

  async deleteHabit(id: number, userId: string): Promise<boolean> {
    const result = await db
      .update(habits)
      .set({ isActive: false, updatedAt: new Date() })
      .where(and(eq(habits.id, id), eq(habits.userId, userId)));
    return (result.rowCount || 0) > 0;
  }

  // Habit completion operations
  async toggleHabitCompletion(habitId: number, userId: string, date: string): Promise<HabitCompletion | null> {
    // Check if already completed today
    const [existing] = await db
      .select()
      .from(habitCompletions)
      .where(and(
        eq(habitCompletions.habitId, habitId),
        eq(habitCompletions.userId, userId),
        eq(habitCompletions.completedAt, date)
      ));

    if (existing) {
      // Remove completion
      await db
        .delete(habitCompletions)
        .where(eq(habitCompletions.id, existing.id));
      return null;
    } else {
      // Add completion
      const [completion] = await db
        .insert(habitCompletions)
        .values({
          habitId,
          userId,
          completedAt: date,
        })
        .returning();
      return completion;
    }
  }

  async getHabitCompletions(userId: string, startDate: string, endDate: string): Promise<HabitCompletion[]> {
    return await db
      .select()
      .from(habitCompletions)
      .where(and(
        eq(habitCompletions.userId, userId),
        gte(habitCompletions.completedAt, startDate),
        lte(habitCompletions.completedAt, endDate)
      ))
      .orderBy(desc(habitCompletions.completedAt));
  }

  async getHabitStats(userId: string): Promise<{
    totalHabits: number;
    completedToday: number;
    currentStreak: number;
    weeklyCompletionRate: number;
    totalPoints: number;
  }> {
    const today = new Date().toISOString().split('T')[0];
    const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

    // Get total active habits
    const [{ totalHabits }] = await db
      .select({ totalHabits: count() })
      .from(habits)
      .where(and(eq(habits.userId, userId), eq(habits.isActive, true)));

    // Get completions today
    const [{ completedToday }] = await db
      .select({ completedToday: count() })
      .from(habitCompletions)
      .where(and(
        eq(habitCompletions.userId, userId),
        eq(habitCompletions.completedAt, today)
      ));

    // Get total points (total completions)
    const [{ totalPoints }] = await db
      .select({ totalPoints: count() })
      .from(habitCompletions)
      .where(eq(habitCompletions.userId, userId));

    // Calculate weekly completion rate
    const weeklyCompletions = await db
      .select({ count: count() })
      .from(habitCompletions)
      .where(and(
        eq(habitCompletions.userId, userId),
        gte(habitCompletions.completedAt, weekAgo)
      ));

    const expectedWeeklyCompletions = totalHabits * 7;
    const weeklyCompletionRate = expectedWeeklyCompletions > 0 
      ? Math.round((weeklyCompletions[0].count / expectedWeeklyCompletions) * 100)
      : 0;

    // Calculate current streak (simplified - longest current streak across all habits)
    const currentStreak = 5; // This would need more complex logic for accurate calculation

    return {
      totalHabits,
      completedToday,
      currentStreak,
      weeklyCompletionRate,
      totalPoints,
    };
  }
}

export const storage = new DatabaseStorage();
