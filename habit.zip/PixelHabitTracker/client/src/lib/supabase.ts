import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://txropvmsufhghohgnehl.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR4cm9wdm1zdWZoZ2hvaGduZWhsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDg5Nzk1NzIsImV4cCI6MjA2NDU1NTU3Mn0.XBhpN2a4q8n7Ba__NQFGEpg6EM5l2lkuKqNvj2y8w40';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);