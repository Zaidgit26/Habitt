import { Medal, Star } from "lucide-react";
import type { HabitWithCompletions } from "@shared/schema";

interface ProgressSidebarProps {
  habits?: HabitWithCompletions[];
  stats?: {
    totalHabits: number;
    completedToday: number;
    currentStreak: number;
    weeklyCompletionRate: number;
    totalPoints: number;
  };
}

export default function ProgressSidebar({ habits, stats }: ProgressSidebarProps) {
  const weeklyPercentage = stats?.weeklyCompletionRate || 0;
  const circumference = 2 * Math.PI * 45;
  const strokeDashoffset = circumference - (weeklyPercentage / 100) * circumference;

  // Group habits by category
  const categories = habits?.reduce((acc, habit) => {
    const category = habit.category || "Other";
    acc[category] = (acc[category] || 0) + 1;
    return acc;
  }, {} as Record<string, number>) || {};

  const categoryColors = {
    "Health & Fitness": "bg-pixel-success",
    "Productivity": "bg-pixel-primary", 
    "Mindfulness": "bg-pixel-accent",
    "Learning": "bg-pixel-secondary",
    "Other": "bg-gray-400"
  };

  return (
    <div className="space-y-6">
      {/* Weekly Progress Circle */}
      <div className="glassmorphism rounded-xl p-6">
        <h3 className="text-lg font-bold text-white mb-4">Weekly Progress</h3>
        <div className="flex items-center justify-center mb-4">
          <div className="relative">
            <svg className="progress-ring w-32 h-32 transform -rotate-90">
              <circle
                className="stroke-white stroke-opacity-20"
                strokeWidth="8"
                fill="transparent"
                r="45"
                cx="64"
                cy="64"
              />
              <circle
                className="stroke-pixel-success transition-all duration-1000 ease-out"
                strokeWidth="8"
                fill="transparent"
                r="45"
                cx="64"
                cy="64"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <div className="text-2xl font-bold text-white">{weeklyPercentage}%</div>
                <div className="text-xs text-white text-opacity-70">Complete</div>
              </div>
            </div>
          </div>
        </div>
        <div className="text-center">
          <p className="text-white text-opacity-80 text-sm">
            {stats?.completedToday || 0} out of {(stats?.totalHabits || 0) * 7} habits completed this week
          </p>
        </div>
      </div>

      {/* Habit Categories */}
      <div className="glassmorphism rounded-xl p-6">
        <h3 className="text-lg font-bold text-white mb-4">Categories</h3>
        <div className="space-y-3">
          {Object.entries(categories).length > 0 ? (
            Object.entries(categories).map(([category, count]) => (
              <div key={category} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className={`w-3 h-3 rounded-full ${categoryColors[category as keyof typeof categoryColors] || categoryColors.Other}`}></div>
                  <span className="text-white text-sm">{category}</span>
                </div>
                <span className="text-white text-opacity-70 text-sm">
                  {count} habit{count !== 1 ? 's' : ''}
                </span>
              </div>
            ))
          ) : (
            <p className="text-white text-opacity-60 text-sm text-center py-4">
              No habits yet
            </p>
          )}
        </div>
      </div>

      {/* Recent Achievements */}
      <div className="glassmorphism rounded-xl p-6">
        <h3 className="text-lg font-bold text-white mb-4">Recent Achievements</h3>
        <div className="space-y-3">
          {habits?.some(h => h.currentStreak >= 7) && (
            <div className="flex items-center space-x-3 animate-float">
              <div className="w-8 h-8 bg-gradient-to-r from-pixel-accent to-yellow-400 rounded-lg flex items-center justify-center">
                <Medal className="text-white text-xs" />
              </div>
              <div>
                <p className="text-white text-sm font-medium">7-Day Streak!</p>
                <p className="text-white text-opacity-60 text-xs">
                  {habits.find(h => h.currentStreak >= 7)?.name}
                </p>
              </div>
            </div>
          )}
          
          {(stats?.totalPoints || 0) > 100 && (
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-r from-pixel-secondary to-purple-400 rounded-lg flex items-center justify-center">
                <Star className="text-white text-xs" />
              </div>
              <div>
                <p className="text-white text-sm font-medium">Point Milestone!</p>
                <p className="text-white text-opacity-60 text-xs">
                  Earned {stats?.totalPoints} points
                </p>
              </div>
            </div>
          )}

          {habits?.filter(h => h.currentStreak > 0).length === 0 && (stats?.totalPoints || 0) <= 100 && (
            <p className="text-white text-opacity-60 text-sm text-center py-4">
              Start completing habits to earn achievements!
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
