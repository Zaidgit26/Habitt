import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { supabase } from "@/lib/supabase";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";
import { LogIn, UserPlus, Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const signInSchema = z.object({
  email: z.string().min(1, "Please enter email or username").refine(
    (value) => value === "admin" || z.string().email().safeParse(value).success,
    "Please enter a valid email address or 'admin'"
  ),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

const signUpSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
});

type SignInData = z.infer<typeof signInSchema>;
type SignUpData = z.infer<typeof signUpSchema>;

interface AuthModalProps {
  trigger?: React.ReactNode;
  defaultTab?: "signin" | "signup";
}

export default function AuthModal({ trigger, defaultTab = "signin" }: AuthModalProps) {
  const [open, setOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const { toast } = useToast();

  const signInForm = useForm<SignInData>({
    resolver: zodResolver(signInSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const signUpForm = useForm<SignUpData>({
    resolver: zodResolver(signUpSchema),
    defaultValues: {
      email: "",
      password: "",
      firstName: "",
      lastName: "",
    },
  });

  const onSignIn = async (data: SignInData) => {
    setIsLoading(true);
    try {
      // Check for default mock user
      if (data.email === "admin" && data.password === "12345678") {
        // Create a mock user session
        const mockUser = {
          id: "mock-admin-user",
          email: "admin@habitcraft.com",
          user_metadata: {
            first_name: "Admin",
            last_name: "User"
          }
        };
        
        // Store mock session in localStorage
        localStorage.setItem('mock-user-session', JSON.stringify(mockUser));
        
        toast({
          title: "Welcome back!",
          description: "Successfully signed in with demo account.",
        });
        setOpen(false);
        signInForm.reset();
        
        // Trigger a page reload to update auth state
        window.location.reload();
        return;
      }

      const { error } = await supabase.auth.signInWithPassword({
        email: data.email,
        password: data.password,
      });

      if (error) {
        toast({
          title: "Sign In Failed",
          description: error.message,
          variant: "destructive",
        });
        return;
      }

      toast({
        title: "Welcome back!",
        description: "Successfully signed in to your account.",
      });
      setOpen(false);
      signInForm.reset();
    } catch (error) {
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const onSignUp = async (data: SignUpData) => {
    setIsLoading(true);
    try {
      const { error } = await supabase.auth.signUp({
        email: data.email,
        password: data.password,
        options: {
          data: {
            first_name: data.firstName,
            last_name: data.lastName,
          },
        },
      });

      if (error) {
        toast({
          title: "Sign Up Failed",
          description: error.message,
          variant: "destructive",
        });
        return;
      }

      toast({
        title: "Account Created!",
        description: "Please check your email to verify your account.",
      });
      setOpen(false);
      signUpForm.reset();
    } catch (error) {
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const defaultTrigger = (
    <Button className="pixel-button bg-gradient-to-r from-pixel-primary to-pixel-secondary hover:shadow-lg">
      <LogIn className="mr-2 h-4 w-4" />
      Get Started
    </Button>
  );

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || defaultTrigger}
      </DialogTrigger>
      <DialogContent className="glassmorphism border-glass-border max-w-md" aria-describedby="auth-dialog-description">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-white text-center playfair">
            Welcome to HabitCraft
          </DialogTitle>
          <p id="auth-dialog-description" className="text-white text-opacity-70 text-center text-sm poppins">
            Sign in to your existing account or create a new account to start tracking your habits
          </p>
        </DialogHeader>

        <Tabs defaultValue={defaultTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 glassmorphism border-0">
            <TabsTrigger 
              value="signin" 
              className="text-white data-[state=active]:bg-white data-[state=active]:bg-opacity-20 data-[state=active]:text-white"
            >
              Sign In
            </TabsTrigger>
            <TabsTrigger 
              value="signup"
              className="text-white data-[state=active]:bg-white data-[state=active]:bg-opacity-20 data-[state=active]:text-white"
            >
              Sign Up
            </TabsTrigger>
          </TabsList>

          <TabsContent value="signin" className="space-y-4 mt-6">
            {/* Demo Credentials Info */}
            <div className="mobile-glassmorphism p-3 sm:p-4 rounded-lg border border-pixel-accent border-opacity-30">
              <p className="text-pixel-accent text-sm font-medium mb-2 poppins">Demo Account</p>
              <p className="text-white text-opacity-80 text-xs poppins">
                Email: <span className="text-pixel-accent font-mono">admin</span> • 
                Password: <span className="text-pixel-accent font-mono">12345678</span>
              </p>
            </div>

            <Form {...signInForm}>
              <form onSubmit={signInForm.handleSubmit(onSignIn)} className="space-y-4">
                <FormField
                  control={signInForm.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white text-sm font-medium poppins">Email</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          type="text"
                          className="glassmorphism text-white placeholder:text-white placeholder:text-opacity-50 border-0 focus:ring-2 focus:ring-pixel-primary poppins"
                          placeholder="Enter your email or 'admin'"
                        />
                      </FormControl>
                      <FormMessage className="text-pixel-danger" />
                    </FormItem>
                  )}
                />

                <FormField
                  control={signInForm.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white text-sm font-medium">Password</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Input
                            {...field}
                            type={showPassword ? "text" : "password"}
                            className="glassmorphism text-white placeholder:text-white placeholder:text-opacity-50 border-0 focus:ring-2 focus:ring-pixel-primary pr-10 poppins"
                            placeholder="Enter password or '12345678'"
                          />
                          <button
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-white text-opacity-70 hover:text-opacity-100"
                          >
                            {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                          </button>
                        </div>
                      </FormControl>
                      <FormMessage className="text-pixel-danger" />
                    </FormItem>
                  )}
                />

                <Button
                  type="submit"
                  disabled={isLoading}
                  className="w-full pixel-button bg-gradient-to-r from-pixel-primary to-pixel-secondary text-white font-medium hover:shadow-lg transition-all"
                >
                  {isLoading ? "Signing In..." : "Sign In"}
                </Button>
              </form>
            </Form>
          </TabsContent>

          <TabsContent value="signup" className="space-y-4 mt-6">
            <Form {...signUpForm}>
              <form onSubmit={signUpForm.handleSubmit(onSignUp)} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={signUpForm.control}
                    name="firstName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white text-sm font-medium">First Name</FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            className="glassmorphism text-white placeholder:text-white placeholder:text-opacity-50 border-0 focus:ring-2 focus:ring-pixel-primary"
                            placeholder="First name"
                          />
                        </FormControl>
                        <FormMessage className="text-pixel-danger" />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={signUpForm.control}
                    name="lastName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white text-sm font-medium">Last Name</FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            className="glassmorphism text-white placeholder:text-white placeholder:text-opacity-50 border-0 focus:ring-2 focus:ring-pixel-primary"
                            placeholder="Last name"
                          />
                        </FormControl>
                        <FormMessage className="text-pixel-danger" />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={signUpForm.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white text-sm font-medium">Email</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          type="email"
                          className="glassmorphism text-white placeholder:text-white placeholder:text-opacity-50 border-0 focus:ring-2 focus:ring-pixel-primary"
                          placeholder="Enter your email"
                        />
                      </FormControl>
                      <FormMessage className="text-pixel-danger" />
                    </FormItem>
                  )}
                />

                <FormField
                  control={signUpForm.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white text-sm font-medium">Password</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Input
                            {...field}
                            type={showPassword ? "text" : "password"}
                            className="glassmorphism text-white placeholder:text-white placeholder:text-opacity-50 border-0 focus:ring-2 focus:ring-pixel-primary pr-10"
                            placeholder="Create a password"
                          />
                          <button
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-white text-opacity-70 hover:text-opacity-100"
                          >
                            {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                          </button>
                        </div>
                      </FormControl>
                      <FormMessage className="text-pixel-danger" />
                    </FormItem>
                  )}
                />

                <Button
                  type="submit"
                  disabled={isLoading}
                  className="w-full pixel-button bg-gradient-to-r from-pixel-secondary to-purple-400 text-white font-medium hover:shadow-lg transition-all"
                >
                  {isLoading ? "Creating Account..." : "Create Account"}
                </Button>
              </form>
            </Form>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}