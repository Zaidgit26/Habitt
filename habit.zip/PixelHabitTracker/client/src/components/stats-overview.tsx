import { Check, Flame, Target, Trophy } from "lucide-react";

interface StatsOverviewProps {
  stats?: {
    totalHabits: number;
    completedToday: number;
    currentStreak: number;
    weeklyCompletionRate: number;
    totalPoints: number;
  };
  isLoading: boolean;
}

export default function StatsOverview({ stats, isLoading }: StatsOverviewProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="glassmorphism rounded-xl p-6 pixel-shadow animate-pulse">
            <div className="h-12 w-12 bg-white bg-opacity-20 rounded-lg mb-4"></div>
            <div className="h-8 bg-white bg-opacity-20 rounded mb-2"></div>
            <div className="h-4 bg-white bg-opacity-20 rounded"></div>
          </div>
        ))}
      </div>
    );
  }

  const completionPercentage = stats?.totalHabits 
    ? Math.round((stats.completedToday / stats.totalHabits) * 100)
    : 0;

  const statCards = [
    {
      title: "Completed Today",
      value: stats?.completedToday || 0,
      icon: Check,
      gradient: "from-pixel-success to-emerald-400",
      change: `${completionPercentage}%`,
      changeColor: "text-pixel-success"
    },
    {
      title: "Current Streak",
      value: stats?.currentStreak || 0,
      icon: Flame,
      gradient: "from-pixel-accent to-yellow-400",
      change: "days",
      changeColor: "text-pixel-accent"
    },
    {
      title: "This Week",
      value: `${stats?.weeklyCompletionRate || 0}%`,
      icon: Target,
      gradient: "from-pixel-primary to-blue-400",
      change: "completion",
      changeColor: "text-blue-400"
    },
    {
      title: "Total Points",
      value: stats?.totalPoints || 0,
      icon: Trophy,
      gradient: "from-pixel-secondary to-purple-400",
      change: "earned",
      changeColor: "text-purple-400"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
      {statCards.map((card, index) => {
        const Icon = card.icon;
        return (
          <div key={index} className="glassmorphism rounded-xl p-6 pixel-shadow hover:shadow-lg transition-all habit-card">
            <div className="flex items-center justify-between mb-4">
              <div className={`w-12 h-12 bg-gradient-to-r ${card.gradient} rounded-lg flex items-center justify-center`}>
                <Icon className="text-white text-xl" />
              </div>
              <span className={`${card.changeColor} text-sm font-medium`}>
                {card.change}
              </span>
            </div>
            <h3 className="text-white text-2xl font-bold mb-1">
              {card.value}
            </h3>
            <p className="text-white text-opacity-70">
              {card.title}
            </p>
          </div>
        );
      })}
    </div>
  );
}
