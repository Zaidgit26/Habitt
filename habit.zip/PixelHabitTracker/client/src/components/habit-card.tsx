import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Flame, Edit, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import type { HabitWithCompletions } from "@shared/schema";

interface HabitCardProps {
  habit: HabitWithCompletions;
}

export default function HabitCard({ habit }: HabitCardProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isToggling, setIsToggling] = useState(false);

  const toggleMutation = useMutation({
    mutationFn: async () => {
      const today = new Date().toISOString().split('T')[0];
      return await apiRequest("POST", `/api/habits/${habit.id}/toggle`, { date: today });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/habits"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      setIsToggling(false);
    },
    onError: (error) => {
      setIsToggling(false);
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update habit completion",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("DELETE", `/api/habits/${habit.id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/habits"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Success",
        description: "Habit deleted successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to delete habit",
        variant: "destructive",
      });
    },
  });

  const handleToggle = () => {
    if (isToggling) return;
    setIsToggling(true);
    toggleMutation.mutate();
  };

  const handleDelete = () => {
    if (confirm("Are you sure you want to delete this habit?")) {
      deleteMutation.mutate();
    }
  };

  const isCompleted = habit.isCompletedToday;
  const opacity = isCompleted ? "opacity-100" : "opacity-70";

  return (
    <div className={`flex items-center justify-between p-4 glassmorphism rounded-lg hover:bg-white hover:bg-opacity-10 transition-all habit-card ${opacity}`}>
      <div className="flex items-center space-x-4">
        <button
          onClick={handleToggle}
          disabled={isToggling}
          className={`w-6 h-6 rounded border-2 flex items-center justify-center transition-all ${
            isToggling 
              ? "animate-pulse" 
              : isCompleted
              ? "border-pixel-success bg-pixel-success hover:scale-110"
              : "border-white border-opacity-30 hover:border-pixel-success hover:bg-pixel-success"
          }`}
        >
          {isCompleted && <span className="text-white text-xs">✓</span>}
        </button>
        <div>
          <h4 className={`text-white font-medium ${isCompleted ? "" : "opacity-70"}`}>
            {habit.name}
          </h4>
          <p className={`text-white text-opacity-60 text-sm ${isCompleted ? "" : "opacity-40"}`}>
            {habit.description || "No description"}
          </p>
        </div>
      </div>
      
      <div className="flex items-center space-x-3">
        {habit.currentStreak > 0 && (
          <div className="flex items-center space-x-1">
            <span className="text-pixel-success text-sm font-medium">
              {habit.currentStreak} day streak
            </span>
            <Flame className="text-pixel-accent h-4 w-4" />
          </div>
        )}
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="text-white hover:bg-white hover:bg-opacity-20">
              ⋮
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="glassmorphism border-glass-border">
            <DropdownMenuItem className="text-white hover:bg-white hover:bg-opacity-10">
              <Edit className="mr-2 h-4 w-4" />
              Edit
            </DropdownMenuItem>
            <DropdownMenuItem 
              className="text-pixel-danger hover:bg-pixel-danger hover:bg-opacity-20"
              onClick={handleDelete}
              disabled={deleteMutation.isPending}
            >
              <Trash2 className="mr-2 h-4 w-4" />
              Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
}
