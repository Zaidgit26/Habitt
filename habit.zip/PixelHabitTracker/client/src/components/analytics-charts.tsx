import { useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { Chart, registerables } from "chart.js";

Chart.register(...registerables);

export default function AnalyticsCharts() {
  const weeklyChartRef = useRef<HTMLCanvasElement>(null);
  const performanceChartRef = useRef<HTMLCanvasElement>(null);
  const weeklyChartInstance = useRef<Chart | null>(null);
  const performanceChartInstance = useRef<Chart | null>(null);

  const { data: completions } = useQuery({
    queryKey: ["/api/completions"],
  });

  const { data: habits } = useQuery({
    queryKey: ["/api/habits"],
  });

  useEffect(() => {
    if (!weeklyChartRef.current) return;

    // Destroy existing chart
    if (weeklyChartInstance.current) {
      weeklyChartInstance.current.destroy();
    }

    // Generate last 7 days of completion data
    const last7Days = [];
    const completionCounts = [];
    
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      const dayName = date.toLocaleDateString('en-US', { weekday: 'short' });
      
      last7Days.push(dayName);
      
      const dayCompletions = completions?.filter(c => c.completedAt === dateStr).length || 0;
      const totalHabits = habits?.length || 1;
      const completionRate = Math.round((dayCompletions / totalHabits) * 100);
      
      completionCounts.push(completionRate);
    }

    weeklyChartInstance.current = new Chart(weeklyChartRef.current, {
      type: 'line',
      data: {
        labels: last7Days,
        datasets: [{
          label: 'Completion Rate',
          data: completionCounts,
          borderColor: '#10B981',
          backgroundColor: 'rgba(16, 185, 129, 0.1)',
          borderWidth: 3,
          fill: true,
          tension: 0.4,
          pointBackgroundColor: '#10B981',
          pointBorderColor: '#ffffff',
          pointBorderWidth: 2,
          pointRadius: 6,
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            labels: {
              color: 'white',
              font: {
                family: 'Inter',
              }
            }
          }
        },
        scales: {
          x: {
            ticks: {
              color: 'rgba(255, 255, 255, 0.7)',
              font: {
                family: 'Inter',
              }
            },
            grid: {
              color: 'rgba(255, 255, 255, 0.1)'
            }
          },
          y: {
            beginAtZero: true,
            max: 100,
            ticks: {
              color: 'rgba(255, 255, 255, 0.7)',
              font: {
                family: 'Inter',
              },
              callback: function(value) {
                return value + '%';
              }
            },
            grid: {
              color: 'rgba(255, 255, 255, 0.1)'
            }
          }
        },
        elements: {
          point: {
            hoverRadius: 8,
          }
        }
      }
    });
  }, [completions, habits]);

  useEffect(() => {
    if (!performanceChartRef.current || !habits) return;

    // Destroy existing chart
    if (performanceChartInstance.current) {
      performanceChartInstance.current.destroy();
    }

    const habitNames = habits.slice(0, 5).map(h => h.name.length > 10 ? h.name.substring(0, 10) + '...' : h.name);
    const completionRates = habits.slice(0, 5).map(h => h.completionRate || 0);

    const colors = [
      '#6366F1',
      '#8B5CF6', 
      '#F59E0B',
      '#10B981',
      '#EF4444'
    ];

    performanceChartInstance.current = new Chart(performanceChartRef.current, {
      type: 'bar',
      data: {
        labels: habitNames,
        datasets: [{
          label: 'Completion %',
          data: completionRates,
          backgroundColor: colors.slice(0, habitNames.length),
          borderRadius: 8,
          borderSkipped: false,
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            labels: {
              color: 'white',
              font: {
                family: 'Inter',
              }
            }
          }
        },
        scales: {
          x: {
            ticks: {
              color: 'rgba(255, 255, 255, 0.7)',
              font: {
                family: 'Inter',
              }
            },
            grid: {
              color: 'rgba(255, 255, 255, 0.1)'
            }
          },
          y: {
            beginAtZero: true,
            max: 100,
            ticks: {
              color: 'rgba(255, 255, 255, 0.7)',
              font: {
                family: 'Inter',
              },
              callback: function(value) {
                return value + '%';
              }
            },
            grid: {
              color: 'rgba(255, 255, 255, 0.1)'
            }
          }
        }
      }
    });
  }, [habits]);

  // Cleanup charts on unmount
  useEffect(() => {
    return () => {
      if (weeklyChartInstance.current) {
        weeklyChartInstance.current.destroy();
      }
      if (performanceChartInstance.current) {
        performanceChartInstance.current.destroy();
      }
    };
  }, []);

  return (
    <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="glassmorphism rounded-xl p-6">
        <h3 className="text-lg font-bold text-white mb-4">Weekly Completion Trend</h3>
        <div className="h-64">
          <canvas ref={weeklyChartRef}></canvas>
        </div>
      </div>
      
      <div className="glassmorphism rounded-xl p-6">
        <h3 className="text-lg font-bold text-white mb-4">Habit Performance</h3>
        <div className="h-64">
          <canvas ref={performanceChartRef}></canvas>
        </div>
      </div>
    </div>
  );
}
