import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { insertHabitSchema } from "@shared/schema";
import { Plus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import type { InsertHabit } from "@shared/schema";

interface AddHabitModalProps {
  trigger?: React.ReactNode;
}

export default function AddHabitModal({ trigger }: AddHabitModalProps) {
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<InsertHabit>({
    resolver: zodResolver(insertHabitSchema),
    defaultValues: {
      name: "",
      description: "",
      frequency: "daily",
      category: "",
      isActive: true,
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertHabit) => {
      return await apiRequest("POST", "/api/habits", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/habits"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Success",
        description: "Habit created successfully!",
      });
      form.reset();
      setOpen(false);
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create habit. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertHabit) => {
    createMutation.mutate(data);
  };

  const defaultTrigger = (
    <Button className="pixel-button glassmorphism text-white hover:bg-white hover:bg-opacity-20 transition-all border-0">
      <Plus className="mr-2 h-4 w-4" />
      New Habit
    </Button>
  );

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || defaultTrigger}
      </DialogTrigger>
      <DialogContent className="glassmorphism border-glass-border max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-white">Add New Habit</DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-white text-sm font-medium">Habit Name</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      className="glassmorphism text-white placeholder:text-white placeholder:text-opacity-50 border-0 focus:ring-2 focus:ring-pixel-primary"
                      placeholder="e.g., Morning Yoga"
                    />
                  </FormControl>
                  <FormMessage className="text-pixel-danger" />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-white text-sm font-medium">Description</FormLabel>
                  <FormControl>
                    <Textarea
                      {...field}
                      className="glassmorphism text-white placeholder:text-white placeholder:text-opacity-50 border-0 focus:ring-2 focus:ring-pixel-primary resize-none"
                      placeholder="Brief description of the habit"
                      rows={3}
                    />
                  </FormControl>
                  <FormMessage className="text-pixel-danger" />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="frequency"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-white text-sm font-medium">Frequency</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger className="glassmorphism text-white border-0 focus:ring-2 focus:ring-pixel-primary">
                        <SelectValue placeholder="Select frequency" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent className="glassmorphism border-glass-border">
                      <SelectItem value="daily" className="text-white hover:bg-white hover:bg-opacity-10">Daily</SelectItem>
                      <SelectItem value="weekly" className="text-white hover:bg-white hover:bg-opacity-10">Weekly</SelectItem>
                      <SelectItem value="monthly" className="text-white hover:bg-white hover:bg-opacity-10">Monthly</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage className="text-pixel-danger" />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-white text-sm font-medium">Category</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      className="glassmorphism text-white placeholder:text-white placeholder:text-opacity-50 border-0 focus:ring-2 focus:ring-pixel-primary"
                      placeholder="e.g., Health & Fitness"
                    />
                  </FormControl>
                  <FormMessage className="text-pixel-danger" />
                </FormItem>
              )}
            />

            <div className="flex space-x-3 pt-4">
              <Button
                type="button"
                variant="ghost"
                className="flex-1 glassmorphism text-white hover:bg-white hover:bg-opacity-10 transition-all"
                onClick={() => setOpen(false)}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={createMutation.isPending}
                className="flex-1 pixel-button bg-gradient-to-r from-pixel-primary to-pixel-secondary text-white font-medium hover:shadow-lg transition-all"
              >
                {createMutation.isPending ? "Creating..." : "Create Habit"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
