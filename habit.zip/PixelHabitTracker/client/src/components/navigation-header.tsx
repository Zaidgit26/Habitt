import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/lib/supabase";
import { BarChart3, Home, Target, Plus, User, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import AddHabitModal from "./add-habit-modal";

export default function NavigationHeader() {
  const { user } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleLogout = async () => {
    // Check if using mock session
    const mockSession = localStorage.getItem('mock-user-session');
    if (mockSession) {
      localStorage.removeItem('mock-user-session');
      window.location.reload();
      return;
    }
    
    // Sign out from Supabase
    await supabase.auth.signOut();
  };

  const userInitials = user?.user_metadata?.first_name && user?.user_metadata?.last_name 
    ? `${user.user_metadata.first_name[0]}${user.user_metadata.last_name[0]}`
    : user?.email?.[0]?.toUpperCase() || "U";

  return (
    <nav className="mobile-glassmorphism sticky top-0 z-50 mobile-padding py-3 sm:py-4">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-2 sm:space-x-3">
          <div className="w-8 h-8 sm:w-10 sm:h-10 pixel-border rounded-lg bg-gradient-to-r from-pixel-primary to-pixel-secondary flex items-center justify-center">
            <BarChart3 className="text-white text-base sm:text-lg" />
          </div>
          <h1 className="mobile-text-lg font-bold text-white playfair">HabitCraft</h1>
        </div>
        
        {/* Desktop Navigation */}
        <div className="hidden lg:flex items-center space-x-4 xl:space-x-6">
          <button className="text-white hover:text-pixel-accent transition-colors poppins text-sm xl:text-base">
            <Home className="mr-2 h-4 w-4 inline" />
            Dashboard
          </button>
          <button className="text-white hover:text-pixel-accent transition-colors poppins text-sm xl:text-base">
            <Target className="mr-2 h-4 w-4 inline" />
            Habits
          </button>
          <button className="text-white hover:text-pixel-accent transition-colors poppins text-sm xl:text-base">
            <BarChart3 className="mr-2 h-4 w-4 inline" />
            Analytics
          </button>
        </div>
        
        <div className="flex items-center space-x-2 sm:space-x-3 lg:space-x-4">
          {/* Add Habit Button */}
          <AddHabitModal
            trigger={
              <Button className="pixel-button mobile-glassmorphism text-white hover:bg-white hover:bg-opacity-20 transition-all border-0 px-2 sm:px-3 lg:px-4 py-2">
                <Plus className="mr-1 sm:mr-2 h-4 w-4" />
                <span className="hidden sm:inline text-sm lg:text-base poppins">New Habit</span>
              </Button>
            }
          />

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="sm"
            className="lg:hidden text-white hover:bg-white hover:bg-opacity-20 p-2"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X className="h-4 w-4 sm:h-5 sm:w-5" /> : <Menu className="h-4 w-4 sm:h-5 sm:w-5" />}
          </Button>

          {/* User Avatar */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="relative h-8 w-8 sm:h-10 sm:w-10 rounded-full p-0">
                <Avatar className="h-8 w-8 sm:h-10 sm:w-10">
                  <AvatarImage 
                    src={user?.user_metadata?.avatar_url} 
                    alt={user?.user_metadata?.first_name || "User"} 
                    className="object-cover"
                  />
                  <AvatarFallback className="bg-gradient-to-r from-pink-500 to-violet-500 text-white text-xs sm:text-sm">
                    {userInitials}
                  </AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-48 sm:w-56 mobile-glassmorphism border-glass-border" align="end">
              <DropdownMenuItem className="text-white hover:bg-white hover:bg-opacity-10 poppins text-sm">
                <User className="mr-2 h-4 w-4" />
                Profile
              </DropdownMenuItem>
              <DropdownMenuItem 
                className="text-white hover:bg-white hover:bg-opacity-10 poppins text-sm"
                onClick={handleLogout}
              >
                Log out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Mobile Navigation Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden mt-4 space-y-2 animate-slide-up">
          <button className="block w-full text-left text-white hover:text-pixel-accent transition-colors py-2">
            <Home className="mr-2 h-4 w-4 inline" />
            Dashboard
          </button>
          <button className="block w-full text-left text-white hover:text-pixel-accent transition-colors py-2">
            <Target className="mr-2 h-4 w-4 inline" />
            Habits
          </button>
          <button className="block w-full text-left text-white hover:text-pixel-accent transition-colors py-2">
            <BarChart3 className="mr-2 h-4 w-4 inline" />
            Analytics
          </button>
        </div>
      )}
    </nav>
  );
}
