import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle, BarChart3, Target, Zap } from "lucide-react";
import AuthModal from "@/components/auth-modal";

export default function Landing() {

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900">
      {/* Navigation */}
      <nav className="mobile-glassmorphism sticky top-0 z-50 mobile-padding py-3 sm:py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-2 sm:space-x-3">
            <div className="w-8 h-8 sm:w-10 sm:h-10 pixel-border rounded-lg bg-gradient-to-r from-pixel-primary to-pixel-secondary flex items-center justify-center">
              <BarChart3 className="text-white text-base sm:text-lg" />
            </div>
            <h1 className="mobile-text-lg font-bold text-white playfair">HabitCraft</h1>
          </div>
          
          <AuthModal />
        </div>
      </nav>

      {/* Hero Section */}
      <div className="max-w-7xl mx-auto mobile-padding py-8 sm:py-12 lg:py-16">
        <div className="text-center mb-8 sm:mb-12 lg:mb-16 animate-slide-up">
          <h2 className="mobile-text-3xl sm:text-4xl lg:text-6xl font-bold text-white mb-4 sm:mb-6 playfair leading-tight">
            Build Better Habits with
            <span className="bg-gradient-to-r from-pixel-primary to-pixel-secondary bg-clip-text text-transparent block sm:inline"> HabitCraft</span>
          </h2>
          <p className="mobile-text-lg text-white text-opacity-80 mb-6 sm:mb-8 max-w-2xl mx-auto poppins">
            Track your daily habits, visualize your progress, and build lasting routines with our advanced 
            analytics and beautiful pixelated glassmorphic interface.
          </p>
          <AuthModal 
            trigger={
              <Button
                size="lg"
                className="pixel-button bg-gradient-to-r from-pixel-primary to-pixel-secondary hover:shadow-lg mobile-text-lg px-6 py-3 sm:px-8 sm:py-4"
              >
                Start Your Journey
                <Zap className="ml-2 h-4 w-4 sm:h-5 sm:w-5" />
              </Button>
            }
          />
        </div>

        {/* Features */}
        <div className="mobile-grid gap-4 sm:gap-6 lg:gap-8 mb-8 sm:mb-12 lg:mb-16">
          <Card className="mobile-glassmorphism border-glass-border pixel-shadow hover:shadow-lg transition-all habit-card">
            <CardContent className="mobile-card-padding text-center">
              <div className="w-12 h-12 sm:w-14 sm:h-14 lg:w-16 lg:h-16 bg-gradient-to-r from-pixel-success to-emerald-400 rounded-lg flex items-center justify-center mx-auto mb-3 sm:mb-4">
                <CheckCircle className="text-white text-lg sm:text-xl lg:text-2xl" />
              </div>
              <h3 className="mobile-text-xl font-bold text-white mb-2 playfair">Smart Tracking</h3>
              <p className="mobile-text-sm text-white text-opacity-70 poppins">
                Easily track your daily habits with our intuitive interface and never miss a day again.
              </p>
            </CardContent>
          </Card>

          <Card className="mobile-glassmorphism border-glass-border pixel-shadow hover:shadow-lg transition-all habit-card">
            <CardContent className="mobile-card-padding text-center">
              <div className="w-12 h-12 sm:w-14 sm:h-14 lg:w-16 lg:h-16 bg-gradient-to-r from-pixel-primary to-blue-400 rounded-lg flex items-center justify-center mx-auto mb-3 sm:mb-4">
                <BarChart3 className="text-white text-lg sm:text-xl lg:text-2xl" />
              </div>
              <h3 className="mobile-text-xl font-bold text-white mb-2 playfair">Advanced Analytics</h3>
              <p className="mobile-text-sm text-white text-opacity-70 poppins">
                Visualize your progress with real-time charts, streak counters, and completion rates.
              </p>
            </CardContent>
          </Card>

          <Card className="mobile-glassmorphism border-glass-border pixel-shadow hover:shadow-lg transition-all habit-card">
            <CardContent className="mobile-card-padding text-center">
              <div className="w-12 h-12 sm:w-14 sm:h-14 lg:w-16 lg:h-16 bg-gradient-to-r from-pixel-accent to-yellow-400 rounded-lg flex items-center justify-center mx-auto mb-3 sm:mb-4">
                <Target className="text-white text-lg sm:text-xl lg:text-2xl" />
              </div>
              <h3 className="mobile-text-xl font-bold text-white mb-2 playfair">Goal Achievement</h3>
              <p className="mobile-text-sm text-white text-opacity-70 poppins">
                Set meaningful goals and watch as you build consistency and achieve lasting change.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* CTA */}
        <div className="text-center">
          <div className="mobile-glassmorphism mobile-card-padding max-w-2xl mx-auto">
            <h3 className="mobile-text-2xl font-bold text-white mb-3 sm:mb-4 playfair">Ready to Transform Your Life?</h3>
            <p className="mobile-text-lg text-white text-opacity-80 mb-4 sm:mb-6 poppins">
              Join thousands of users who have already started building better habits with HabitCraft.
            </p>
            <AuthModal 
              trigger={
                <Button
                  size="lg"
                  className="pixel-button bg-gradient-to-r from-pixel-secondary to-purple-400 hover:shadow-lg mobile-text-lg px-6 py-3 sm:px-8 sm:py-4"
                >
                  Get Started for Free
                </Button>
              }
            />
          </div>
        </div>
      </div>
    </div>
  );
}
