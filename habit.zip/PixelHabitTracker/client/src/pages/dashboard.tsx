import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import NavigationHeader from "@/components/navigation-header";
import StatsOverview from "@/components/stats-overview";
import HabitCard from "@/components/habit-card";
import ProgressSidebar from "@/components/progress-sidebar";
import AnalyticsCharts from "@/components/analytics-charts";
import AddHabitModal from "@/components/add-habit-modal";
import { useQuery } from "@tanstack/react-query";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { HabitWithCompletions } from "@shared/schema";

export default function Dashboard() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading, user } = useAuth();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: habits, isLoading: habitsLoading } = useQuery<HabitWithCompletions[]>({
    queryKey: ["/api/habits"],
    enabled: !!user,
  });

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/stats"],
    enabled: !!user,
  });

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 flex items-center justify-center">
        <div className="glassmorphism rounded-xl p-8 text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto mb-4"></div>
          <p className="text-white">Loading...</p>
        </div>
      </div>
    );
  }

  const greeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good morning";
    if (hour < 18) return "Good afternoon";
    return "Good evening";
  };

  const userName = user?.user_metadata?.first_name || "there";
  const totalHabits = habits?.length || 0;
  const completedToday = habits?.filter(h => h.isCompletedToday).length || 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900">
      <NavigationHeader />
      
      <div className="max-w-7xl mx-auto mobile-padding py-4 sm:py-6 lg:py-8">
        {/* Dashboard Header */}
        <div className="mb-6 sm:mb-8 animate-slide-up">
          <h2 className="mobile-text-3xl font-bold text-white mb-2 playfair">
            {greeting()}, {userName}!
          </h2>
          <p className="mobile-text-lg text-white text-opacity-80 poppins">
            You've completed {completedToday} out of {totalHabits} habits today. Keep it up!
          </p>
        </div>

        {/* Stats Overview */}
        <StatsOverview stats={stats} isLoading={statsLoading} />

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 sm:gap-6 lg:gap-8">
          {/* Today's Habits */}
          <div className="xl:col-span-2">
            <div className="mobile-glassmorphism mobile-card-padding mb-4 sm:mb-6">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4 sm:mb-6 space-y-3 sm:space-y-0">
                <h3 className="mobile-text-xl font-bold text-white playfair">Today's Habits</h3>
                <div className="flex items-center space-x-2 sm:space-x-3">
                  <span className="mobile-text-sm text-white text-opacity-70 poppins">
                    {completedToday}/{totalHabits} completed
                  </span>
                  <div className="w-16 sm:w-20 lg:w-24 h-2 bg-white bg-opacity-20 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-pixel-success to-emerald-400 rounded-full transition-all duration-500"
                      style={{ width: totalHabits > 0 ? `${(completedToday / totalHabits) * 100}%` : '0%' }}
                    ></div>
                  </div>
                </div>
              </div>

              <div className="space-y-3 sm:space-y-4">
                {habitsLoading ? (
                  <div className="text-center py-6 sm:py-8">
                    <div className="animate-spin rounded-full h-6 w-6 sm:h-8 sm:w-8 border-b-2 border-white mx-auto mb-3 sm:mb-4"></div>
                    <p className="mobile-text-sm text-white text-opacity-70 poppins">Loading habits...</p>
                  </div>
                ) : habits && habits.length > 0 ? (
                  habits.map((habit) => (
                    <HabitCard key={habit.id} habit={habit} />
                  ))
                ) : (
                  <div className="text-center py-6 sm:py-8">
                    <p className="mobile-text-sm text-white text-opacity-70 mb-3 sm:mb-4 poppins">No habits yet. Create your first habit!</p>
                    <AddHabitModal 
                      trigger={
                        <button className="pixel-button bg-gradient-to-r from-pixel-primary to-pixel-secondary px-3 sm:px-4 py-2 rounded-lg text-white font-medium hover:shadow-lg transition-all mobile-text-sm poppins">
                          Add Your First Habit
                        </button>
                      }
                    />
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Progress Sidebar */}
          <ProgressSidebar habits={habits} stats={stats} />
        </div>

        {/* Analytics Charts */}
        <AnalyticsCharts />
      </div>

      {/* Add Habit Modal */}
      <AddHabitModal />
    </div>
  );
}
