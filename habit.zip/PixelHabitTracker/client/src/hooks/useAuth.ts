import { useState, useEffect } from "react";
import { supabase } from "@/lib/supabase";
import { User } from "@supabase/supabase-js";

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Get initial session
    const getInitialSession = async () => {
      // Check for mock user session first
      const mockSession = localStorage.getItem('mock-user-session');
      if (mockSession) {
        try {
          const mockUser = JSON.parse(mockSession);
          setUser(mockUser as User);
          setIsLoading(false);
          return;
        } catch (error) {
          localStorage.removeItem('mock-user-session');
        }
      }

      // Check Supabase session
      const { data: { session } } = await supabase.auth.getSession();
      setUser(session?.user ?? null);
      setIsLoading(false);
    };

    getInitialSession();

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        // Clear mock session when Supabase auth changes
        if (event === 'SIGNED_IN' || event === 'SIGNED_OUT') {
          localStorage.removeItem('mock-user-session');
        }
        setUser(session?.user ?? null);
        setIsLoading(false);
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  return {
    user,
    isLoading,
    isAuthenticated: !!user,
  };
}
